var searchData=
[
  ['processinfo',['ProcessInfo',['../dd/dc8/structProcessInfo.xhtml',1,'']]]
];
