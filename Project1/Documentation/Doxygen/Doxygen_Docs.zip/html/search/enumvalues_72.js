var searchData=
[
  ['ready',['ready',['../da/d42/process_8h.xhtml#a2c72cb00af5be695c1f898162350821fa3d4001ca586c857718be397374082d76',1,'process.h']]],
  ['running',['running',['../da/d42/process_8h.xhtml#a2c72cb00af5be695c1f898162350821faf9ccc71a0c4e71cc139d2c885154b243',1,'process.h']]]
];
