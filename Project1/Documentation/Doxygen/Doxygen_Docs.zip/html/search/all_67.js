var searchData=
[
  ['getid',['getID',['../de/dd4/classcIDManager.xhtml#a45420147e785cc219743e9aa2c336501',1,'cIDManager']]],
  ['getnexttorun',['getNextToRun',['../d6/dc3/classcFCFS.xhtml#aa2b92a8a992078e499aab455c9d78faf',1,'cFCFS::getNextToRun()'],['../d0/d21/classcScheduler.xhtml#a350ad7c55ddcdd17005778b0da241956',1,'cScheduler::getNextToRun()']]],
  ['getopcode',['getOpcode',['../d2/dc6/classcCPU.xhtml#a987e1ab511c71dcde48411f5bb16f9d8',1,'cCPU']]],
  ['getparam',['getParam',['../d2/dc6/classcCPU.xhtml#a891d9b77e1818ca247e9d76f4db99415',1,'cCPU']]],
  ['getpsw',['getPSW',['../d2/dc6/classcCPU.xhtml#ad485374a709476e2dfb847046d3d5215',1,'cCPU']]],
  ['getsetpc',['getSetPC',['../d2/dc6/classcCPU.xhtml#ab04938ac939d530e521181db6a52944f',1,'cCPU']]],
  ['getsetpsw',['getSetPSW',['../d2/dc6/classcCPU.xhtml#a0b13774a76c6b04d760b8ff072c37a85',1,'cCPU']]],
  ['getsetvc',['getSetVC',['../d2/dc6/classcCPU.xhtml#a2d593a0d3d66e532826db4754d5fc4d2',1,'cCPU']]],
  ['gettime',['getTime',['../dc/d14/classClockDevice.xhtml#a6dd7b50cf793e37514890eff3e7adf95',1,'ClockDevice']]]
];
