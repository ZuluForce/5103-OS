var searchData=
[
  ['blocked',['blocked',['../da/d42/process_8h.xhtml#a2c72cb00af5be695c1f898162350821fa035732e2026cb263f1bd9eee6ca6ae01',1,'process.h']]]
];
