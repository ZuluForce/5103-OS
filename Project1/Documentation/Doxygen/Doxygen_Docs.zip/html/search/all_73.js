var searchData=
[
  ['setpsw',['setPSW',['../d2/dc6/classcCPU.xhtml#adb6ad793398d28b5615dd1377a619084',1,'cCPU']]],
  ['settext',['setText',['../d2/dc6/classcCPU.xhtml#acd957640be8abb7c0d8a24010ed0e737',1,'cCPU']]],
  ['settimer',['setTimer',['../dc/d14/classClockDevice.xhtml#a780eebde86fb6a6400894128ac37fa37',1,'ClockDevice']]],
  ['sighandler',['sigHandler',['../db/da5/classcKernel.xhtml#a60ccaffeee3cfcfdfb4aa7b9e33b19f4',1,'cKernel']]],
  ['state',['state',['../dd/dc8/structProcessInfo.xhtml#a748790bb8c3ef5d2dff552f35b81298e',1,'ProcessInfo']]],
  ['swapprocesses',['swapProcesses',['../db/da5/classcKernel.xhtml#a1a0cb2a56afb1e4adfd3bb05156aec81',1,'cKernel']]]
];
