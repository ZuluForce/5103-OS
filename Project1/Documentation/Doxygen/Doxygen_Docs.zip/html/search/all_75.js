var searchData=
[
  ['unblockprocess',['unblockProcess',['../d6/dc3/classcFCFS.xhtml#a793da0298f9b36ab8505a0e3daaf41ec',1,'cFCFS::unblockProcess()'],['../d0/d21/classcScheduler.xhtml#a81fe2e5e5e2334e36db1cbf491e3fa57',1,'cScheduler::unblockProcess()']]]
];
