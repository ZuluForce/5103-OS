var searchData=
[
  ['blocksig',['BLOCKSIG',['../db/d9a/block__device_8h.xhtml#a40b115b8cd111feee88bd339876e7941',1,'block_device.h']]]
];
