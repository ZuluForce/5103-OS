var searchData=
[
  ['max_5fparam_5fsize',['MAX_PARAM_SIZE',['../dc/da7/cpu_8h.xhtml#a9e34e5196b1f8e4c96f229d062c73fe0',1,'cpu.h']]],
  ['max_5fparams',['MAX_PARAMS',['../dc/da7/cpu_8h.xhtml#a885a6481fc6d474d0be18bc0facf648d',1,'cpu.h']]]
];
