var searchData=
[
  ['ps_5fexception',['PS_EXCEPTION',['../dc/da7/cpu_8h.xhtml#ade10811b11f1c647313bf0a60797a9f9a5f0829985f41a81da1a46db3501075f1',1,'cpu.h']]],
  ['ps_5fsyscall',['PS_SYSCALL',['../dc/da7/cpu_8h.xhtml#ade10811b11f1c647313bf0a60797a9f9aa95675f79e2e3167dc1622eaf4733cee',1,'cpu.h']]],
  ['ps_5fterminate',['PS_TERMINATE',['../dc/da7/cpu_8h.xhtml#ade10811b11f1c647313bf0a60797a9f9a45657e0129f354aef59ae454ef5443fd',1,'cpu.h']]]
];
