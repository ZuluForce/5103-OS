var searchData=
[
  ['initprocessname',['initProcessName',['../d0/daa/kernel_8h.xhtml#a9bd73e11b6d2b66703cd822d0c2ecd32',1,'kernel.h']]]
];
