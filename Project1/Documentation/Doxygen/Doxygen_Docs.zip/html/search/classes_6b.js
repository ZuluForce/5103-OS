var searchData=
[
  ['kernelerror',['kernelError',['../dc/d4b/structkernelError.xhtml',1,'']]]
];
