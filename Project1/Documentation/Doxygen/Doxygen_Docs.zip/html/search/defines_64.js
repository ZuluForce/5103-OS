var searchData=
[
  ['default_5fpriority',['DEFAULT_PRIORITY',['../d0/daa/kernel_8h.xhtml#a0756f011ef667460d583017366823244',1,'kernel.h']]],
  ['default_5ftimer',['DEFAULT_TIMER',['../d0/daa/kernel_8h.xhtml#ac91bd56eef3f2b82894a058b7f136a21',1,'kernel.h']]]
];
