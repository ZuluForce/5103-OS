var searchData=
[
  ['kernel_2eh',['kernel.h',['../d0/daa/kernel_8h.xhtml',1,'']]],
  ['kernelerror',['kernelError',['../dc/d4b/structkernelError.xhtml',1,'']]]
];
