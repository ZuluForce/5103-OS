var searchData=
[
  ['initprocess',['initProcess',['../db/da5/classcKernel.xhtml#a5440eace2647ffd5279de55600947b84',1,'cKernel']]],
  ['initprocessname',['initProcessName',['../d0/daa/kernel_8h.xhtml#a9bd73e11b6d2b66703cd822d0c2ecd32',1,'kernel.h']]]
];
