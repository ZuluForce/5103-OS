var searchData=
[
  ['state',['state',['../dd/dc8/structProcessInfo.xhtml#a748790bb8c3ef5d2dff552f35b81298e',1,'ProcessInfo']]]
];
